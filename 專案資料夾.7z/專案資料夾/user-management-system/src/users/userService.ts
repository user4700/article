export class UserService {
    getUserData(userId: string) {
        // 實作用戶資料獲取邏輯
    }

    updateUserData(userId: string, userData: any) {
        // 實作用戶資料更新邏輯
    }
}