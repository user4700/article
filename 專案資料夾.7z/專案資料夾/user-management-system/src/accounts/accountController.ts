class AccountController {
    register(req, res) {
        // 註冊邏輯
    }

    login(req, res) {
        // 登入邏輯
    }
}

export default AccountController;