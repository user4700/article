export class AccountService {
    validateRegistration(data: any): boolean {
        // 驗證註冊資料的邏輯
        // TODO: 實作驗證邏輯
        return true; // 假設驗證通過
    }

    validateLogin(credentials: any): boolean {
        // 驗證登入資料的邏輯
        // TODO: 實作驗證邏輯
        return true; // 假設驗證通過
    }
}