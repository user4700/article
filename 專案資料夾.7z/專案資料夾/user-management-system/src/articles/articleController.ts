class ArticleController {
    async getHistory(req, res) {
        // 獲取文章歷史紀錄的邏輯
    }

    async loadHistory(req, res) {
        // 載入文章歷史紀錄的邏輯
    }
}

export default ArticleController;